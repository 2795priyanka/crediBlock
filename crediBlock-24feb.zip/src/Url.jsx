
const Server = "http://3.138.38.80:3113/";


export const SERVER = "http://3.138.38.80:3113/";
export const SIGN_UP = Server + "userSignup";
export const LOGIN = Server + "userLogin?";
// export const ACCESS_CHAT = `http://localhost:3111/chat/createChat`;
// export const FETCH_CHAT = Server + "chat/fetchchat";
// export const ALL_CHAT = Server + "chat/allChat";
// export const SEND_MESSAGE = Server + "message/sendMessage";
// export const VIEW_BROKER = Server + "getAllBroker";
export const FORGOT_PASSWORD = Server + "forgotpassword";
export const VERIFY_OTP = Server + "verify_otp?";
export const RESET_PWD =Server + "updatePassword?";


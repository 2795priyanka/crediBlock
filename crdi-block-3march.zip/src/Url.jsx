
const Server = "http://3.138.38.80:3113/";


export const SERVER = "http://3.138.38.80:3113/";
export const SIGN_UP = Server + "userSignup";
export const LOGIN = Server + "userLogin?";
export const FORGOT_PASSWORD = Server + "forgotpassword";
export const VERIFY_OTP = Server + "verify_otp?";
export const RESET_PWD =Server + "updatePassword?";

